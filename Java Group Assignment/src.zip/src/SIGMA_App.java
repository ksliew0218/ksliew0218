
import domain.PurchaseRequisition;
import view.View;

public class SIGMA_App {
    public static void main(String[] args)
    {
        new View().mainMenu();
    }
}
