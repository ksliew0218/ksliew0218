package domain;
import utility.Utility;

import java.util.*;
public class Sales_Manager {
    public Sales_Manager(){}

}
