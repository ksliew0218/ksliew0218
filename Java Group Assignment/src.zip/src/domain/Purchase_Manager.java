package domain;

public class Purchase_Manager {
}
