package domain;

public interface Entry {
    void add();
    void edit();
    void delete();
    void view();
}
